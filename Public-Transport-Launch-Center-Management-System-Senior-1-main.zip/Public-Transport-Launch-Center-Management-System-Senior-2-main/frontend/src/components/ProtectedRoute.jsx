import { Navigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function ProtectedRoute({ children, roles }) {
    const { user, loading } = useAuth();

    if (loading) {
        return (
            <div className="flex items-center justify-center min-h-screen">
                <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
            </div>
        );
    }

    if (!user) {
        return <Navigate to="/login" replace />;
    }

    if (roles && !roles.some(r => r === user.role || r === getRoleName(user.role))) {
        return <Navigate to="/" replace />;
    }

    return children;
}

function getRoleName(role) {
    const map = { 0: 'Admin', 1: 'Driver', 2: 'Citizen' };
    return map[role] || role;
}
