import os
import logging
from datetime import datetime, timedelta, date, time
from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
from flask_migrate import Migrate
import uuid
from models import db, User, Driver, Bus, Route, Trip, Ticket, Complaint, Notification

# Configure logging
logging.basicConfig(level=logging.DEBUG)

app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "fallback_secret_key")

# Database configuration
database_url = os.environ.get("DATABASE_URL")
if not database_url:
    raise RuntimeError("DATABASE_URL environment variable is not set")

app.config["SQLALCHEMY_DATABASE_URI"] = database_url
app.config["SQLALCHEMY_ENGINE_OPTIONS"] = {
    "pool_recycle": 300,
    "pool_pre_ping": True,
}
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

# Initialize database and migration
db.init_app(app)
migrate = Migrate(app, db)

# Initialize database with sample data
def init_database():
    """Initialize database with sample data if empty"""
    with app.app_context():
        # Create all tables
        db.create_all()
        
        # Check if data already exists
        if User.query.first():
            return
        
        # Create admin user
        admin_user = User(
            username='admin',
            password='admin123',
            role='garage_manager',
            name='System Administrator',
            email='admin@ptms.gov'
        )
        db.session.add(admin_user)
        
        # Create sample routes
        route1 = Route(
            start_point='Downtown Terminal',
            end_point='Airport',
            description='Main route to airport via city center'
        )
        route2 = Route(
            start_point='University',
            end_point='Shopping Mall',
            description='Student and shopper route'
        )
        db.session.add_all([route1, route2])
        
        # Create sample buses
        bus1 = Bus(
            plate_number='ABC123',
            type='City Bus',
            model='Volvo B7R',
            capacity=50,
            status='Active'
        )
        bus2 = Bus(
            plate_number='XYZ789',
            type='Express Bus',
            model='Mercedes Citaro',
            capacity=40,
            status='Active'
        )
        db.session.add_all([bus1, bus2])
        
        # Commit to get IDs
        db.session.commit()
        
        # Create driver users and drivers
        driver_user1 = User(
            username='driver1',
            password='driver123',
            role='driver',
            name='John Smith',
            email='john@ptms.gov',
            phone='+1234567890'
        )
        driver_user2 = User(
            username='driver2',
            password='driver123',
            role='driver',
            name='Sarah Johnson',
            email='sarah@ptms.gov',
            phone='+1987654321'
        )
        db.session.add_all([driver_user1, driver_user2])
        db.session.commit()
        
        driver1 = Driver(
            user_id=driver_user1.id,
            license_no='DL12345678'
        )
        driver2 = Driver(
            user_id=driver_user2.id,
            license_no='DL87654321'
        )
        db.session.add_all([driver1, driver2])
        db.session.commit()
        
        # Create sample trips
        trip1 = Trip(
            route_id=route1.id,
            bus_id=bus1.id,
            driver_id=driver1.id,
            date=date(2025, 6, 19),
            time=time(8, 0),
            status='Scheduled',
            available_seats=45
        )
        trip2 = Trip(
            route_id=route2.id,
            bus_id=bus2.id,
            driver_id=driver2.id,
            date=date(2025, 6, 19),
            time=time(9, 30),
            status='Scheduled',
            available_seats=38
        )
        db.session.add_all([trip1, trip2])
        
        # Create sample ticket
        ticket1 = Ticket(
            trip_id=trip1.id,
            passenger_name='Alice Brown',
            passenger_id='ID123456',
            passenger_phone='+1122334455',
            reference_number='TKT001',
            booking_date=date(2025, 6, 18)
        )
        db.session.add(ticket1)
        
        # Create sample complaints
        complaint1 = Complaint(
            user_type='passenger',
            type='driver',
            description='Driver was rude during the trip',
            status='pending'
        )
        complaint2 = Complaint(
            user_type='driver',
            type='vehicle',
            description='Bus air conditioning not working',
            status='pending'
        )
        db.session.add_all([complaint1, complaint2])
        
        db.session.commit()

@app.route('/')
def index():
    if 'user_role' in session:
        if session['user_role'] == 'garage_manager':
            return redirect(url_for('garage_manager'))
        elif session['user_role'] == 'driver':
            return redirect(url_for('driver'))
        elif session['user_role'] == 'passenger':
            return redirect(url_for('passenger'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        # Find user in database
        user = User.query.filter_by(username=username, password=password).first()
        
        if user:
            session['user_id'] = user.id
            session['user_role'] = user.role
            session['username'] = user.username
            session['name'] = user.name
            
            if user.role == 'driver' and user.driver:
                session['driver_id'] = user.driver.id
            
            return redirect(url_for('index'))
        else:
            flash('اسم المستخدم أو كلمة المرور غير صحيحة', 'error')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        name = request.form.get('name')
        email = request.form.get('email')
        phone = request.form.get('phone')
        
        # Check if username already exists
        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            flash('اسم المستخدم موجود بالفعل', 'error')
            return render_template('register.html')
        
        # Create new passenger user
        new_user = User(
            username=username,
            password=password,
            role='passenger',
            name=name,
            email=email,
            phone=phone
        )
        
        db.session.add(new_user)
        db.session.commit()
        flash('تم إنشاء الحساب بنجاح! يمكنك الآن تسجيل الدخول', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/garage_manager')
def garage_manager():
    if session.get('user_role') != 'garage_manager':
        return redirect(url_for('login'))
    
    drivers = Driver.query.join(User).all()
    buses = Bus.query.all()
    routes = Route.query.all()
    trips = Trip.query.all()
    complaints = Complaint.query.all()
    
    return render_template('garage_manager.html', 
                         drivers=drivers, 
                         buses=buses, 
                         routes=routes, 
                         trips=trips, 
                         complaints=complaints)

@app.route('/driver')
def driver():
    if session.get('user_role') != 'driver':
        return redirect(url_for('login'))
    
    driver_id = session.get('driver_id')
    driver_trips = Trip.query.filter_by(driver_id=driver_id).all()
    
    # Get buses assigned to this driver through trips
    assigned_buses = []
    if driver_trips:
        bus_ids = list(set([trip.bus_id for trip in driver_trips]))
        assigned_buses = Bus.query.filter(Bus.id.in_(bus_ids)).all()
    
    # Get the most recent bus for display (or first if multiple)
    assigned_bus = assigned_buses[0] if assigned_buses else None
    
    return render_template('driver.html', 
                         trips=driver_trips, 
                         bus=assigned_bus,
                         assigned_buses=assigned_buses,
                         driver_id=driver_id)

@app.route('/passenger')
def passenger():
    if session.get('user_role') != 'passenger':
        return redirect(url_for('login'))
    
    # Get trips with route and bus details
    trips = Trip.query.join(Route).join(Bus).all()
    
    return render_template('passenger.html', trips=trips)

# Garage Manager APIs
@app.route('/api/add_driver', methods=['POST'])
def add_driver():
    if session.get('user_role') != 'garage_manager':
        return jsonify({'success': False, 'message': 'Unauthorized'})
    
    name = request.form.get('name')
    email = request.form.get('email')
    username = request.form.get('username')
    password = request.form.get('password')
    license_no = request.form.get('license_no')
    phone = request.form.get('phone')
    
    # Check if username already exists
    existing_user = User.query.filter_by(username=username).first()
    if existing_user:
        return jsonify({'success': False, 'message': 'اسم المستخدم موجود بالفعل'})
    
    # Create user account for driver
    user_data = User(
        username=username,
        password=password,
        role='driver',
        name=name,
        email=email,
        phone=phone
    )
    db.session.add(user_data)
    db.session.commit()
    
    # Create driver record
    driver_data = Driver(
        user_id=user_data.id,
        license_no=license_no
    )
    db.session.add(driver_data)
    db.session.commit()
    
    return jsonify({'success': True, 'driver': {
        'id': driver_data.id,
        'name': name,
        'license_no': license_no,
        'phone': phone,
        'email': email
    }, 'user': {'username': username}})

@app.route('/api/add_bus', methods=['POST'])
def add_bus():
    if session.get('user_role') != 'garage_manager':
        return jsonify({'success': False, 'message': 'Unauthorized'})
    
    plate_number = request.form.get('plate_number')
    bus_type = request.form.get('type')
    model = request.form.get('model')
    capacity_str = request.form.get('capacity')
    status = request.form.get('status')
    
    if not all([plate_number, bus_type, model, capacity_str]):
        return jsonify({'success': False, 'message': 'Missing required fields'})
    
    # Check if plate number already exists
    existing_bus = Bus.query.filter_by(plate_number=plate_number).first()
    if existing_bus:
        return jsonify({'success': False, 'message': 'رقم اللوحة موجود بالفعل'})
    
    try:
        capacity = int(capacity_str)
    except ValueError:
        return jsonify({'success': False, 'message': 'السعة يجب أن تكون رقماً'})
    
    bus_data = Bus(
        plate_number=plate_number,
        type=bus_type,
        model=model,
        capacity=capacity,
        status=status or 'Active'
    )
    
    db.session.add(bus_data)
    db.session.commit()
    
    return jsonify({'success': True, 'bus': {
        'id': bus_data.id,
        'plate_number': bus_data.plate_number,
        'type': bus_data.type,
        'model': bus_data.model,
        'capacity': bus_data.capacity,
        'status': bus_data.status
    }})

@app.route('/api/update_bus', methods=['POST'])
def update_bus():
    if session.get('user_role') != 'garage_manager':
        return jsonify({'success': False, 'message': 'Unauthorized'})
    
    bus_id_str = request.form.get('bus_id')
    if not bus_id_str:
        return jsonify({'success': False, 'message': 'Bus ID is required'})
    
    bus_id = int(bus_id_str)
    bus = Bus.query.get(bus_id)
    
    if bus:
        bus.plate_number = request.form.get('plate_number')
        bus.type = request.form.get('type')
        bus.model = request.form.get('model')
        capacity_str = request.form.get('capacity')
        if capacity_str:
            bus.capacity = int(capacity_str)
        bus.status = request.form.get('status')
        
        db.session.commit()
        return jsonify({'success': True, 'bus': {
            'id': bus.id,
            'plate_number': bus.plate_number,
            'type': bus.type,
            'model': bus.model,
            'capacity': bus.capacity,
            'status': bus.status
        }})
    
    return jsonify({'success': False, 'message': 'Bus not found'})

@app.route('/api/add_route', methods=['POST'])
def add_route():
    if session.get('user_role') != 'garage_manager':
        return jsonify({'success': False, 'message': 'Unauthorized'})
    
    start_point = request.form.get('start_point')
    end_point = request.form.get('end_point')
    
    # Check for duplicates
    existing_route = Route.query.filter_by(start_point=start_point, end_point=end_point).first()
    if existing_route:
        return jsonify({'success': False, 'message': 'Route already exists'})
    
    route_data = Route(
        start_point=start_point,
        end_point=end_point,
        description=request.form.get('description')
    )
    
    db.session.add(route_data)
    db.session.commit()
    
    return jsonify({'success': True, 'route': {
        'id': route_data.id,
        'start_point': route_data.start_point,
        'end_point': route_data.end_point,
        'description': route_data.description
    }})

@app.route('/api/add_trip', methods=['POST'])
def add_trip():
    if session.get('user_role') != 'garage_manager':
        return jsonify({'success': False, 'message': 'Unauthorized'})
    
    bus_id_str = request.form.get('bus_id')
    route_id_str = request.form.get('route_id')
    driver_id_str = request.form.get('driver_id')
    
    if not all([bus_id_str, route_id_str, driver_id_str]):
        return jsonify({'success': False, 'message': 'Missing required fields'})
    
    bus_id = int(bus_id_str)
    bus = Bus.query.get(bus_id)
    
    from datetime import datetime
    trip_date = datetime.strptime(request.form.get('date'), '%Y-%m-%d').date()
    trip_time = datetime.strptime(request.form.get('time'), '%H:%M').time()
    
    trip_data = Trip(
        route_id=int(route_id_str),
        bus_id=bus_id,
        driver_id=int(driver_id_str),
        date=trip_date,
        time=trip_time,
        status='Scheduled',
        available_seats=bus.capacity if bus else 50
    )
    
    db.session.add(trip_data)
    db.session.commit()
    
    return jsonify({'success': True, 'trip': {
        'id': trip_data.id,
        'route_id': trip_data.route_id,
        'bus_id': trip_data.bus_id,
        'driver_id': trip_data.driver_id,
        'date': str(trip_data.date),
        'time': str(trip_data.time),
        'status': trip_data.status,
        'available_seats': trip_data.available_seats
    }})

@app.route('/api/respond_complaint', methods=['POST'])
def respond_complaint():
    if session.get('user_role') != 'garage_manager':
        return jsonify({'success': False, 'message': 'Unauthorized'})
    
    complaint_id_str = request.form.get('complaint_id')
    if not complaint_id_str:
        return jsonify({'success': False, 'message': 'Complaint ID is required'})
    
    complaint_id = int(complaint_id_str)
    complaint = Complaint.query.get(complaint_id)
    
    if complaint:
        complaint.response = request.form.get('response')
        complaint.status = 'resolved'
        complaint.responded_at = datetime.utcnow()
        
        db.session.commit()
        return jsonify({'success': True, 'complaint': {
            'id': complaint.id,
            'response': complaint.response,
            'status': complaint.status
        }})
    
    return jsonify({'success': False, 'message': 'Complaint not found'})

# Driver APIs
@app.route('/api/submit_emergency', methods=['POST'])
def submit_emergency():
    if session.get('user_role') != 'driver':
        return jsonify({'success': False, 'message': 'Unauthorized'})
    
    notification_data = Notification(
        type='emergency',
        issue_type=request.form.get('issue_type'),
        description=request.form.get('description'),
        driver_id=session.get('driver_id'),
        status='pending'
    )
    
    db.session.add(notification_data)
    db.session.commit()
    
    return jsonify({'success': True, 'message': 'Emergency notification sent successfully'})

@app.route('/api/update_trip_status', methods=['POST'])
def update_trip_status():
    if session.get('user_role') != 'driver':
        return jsonify({'success': False, 'message': 'Unauthorized'})
    
    trip_id_str = request.form.get('trip_id')
    if not trip_id_str:
        return jsonify({'success': False, 'message': 'Trip ID is required'})
    
    trip_id = int(trip_id_str)
    new_status = request.form.get('status')
    
    trip = Trip.query.get(trip_id)
    if trip and trip.driver_id == session.get('driver_id'):
        trip.status = new_status
        db.session.commit()
        return jsonify({'success': True, 'trip': {
            'id': trip.id,
            'status': trip.status
        }})
    
    return jsonify({'success': False, 'message': 'Trip not found or unauthorized'})

@app.route('/api/file_complaint', methods=['POST'])
def file_complaint():
    user_role = session.get('user_role')
    if user_role not in ['driver', 'passenger']:
        return jsonify({'success': False, 'message': 'Unauthorized'})
    
    complaint_data = Complaint(
        user_type=user_role,
        type=request.form.get('type'),
        description=request.form.get('description'),
        status='pending'
    )
    
    db.session.add(complaint_data)
    db.session.commit()
    
    return jsonify({'success': True, 'message': 'Complaint submitted successfully'})

# Passenger APIs
@app.route('/api/book_ticket', methods=['POST'])
def book_ticket():
    if session.get('user_role') != 'passenger':
        return jsonify({'success': False, 'message': 'Unauthorized'})
    
    trip_id_str = request.form.get('trip_id')
    if not trip_id_str:
        return jsonify({'success': False, 'message': 'Trip ID is required'})
    
    trip_id = int(trip_id_str)
    trip = Trip.query.get(trip_id)
    
    if not trip or trip.available_seats <= 0:
        return jsonify({'success': False, 'message': 'No available seats'})
    
    reference_number = f"TKT{str(uuid.uuid4())[:8].upper()}"
    
    ticket_data = Ticket(
        trip_id=trip_id,
        passenger_name=request.form.get('passenger_name'),
        passenger_id=request.form.get('passenger_id'),
        passenger_phone=request.form.get('passenger_phone'),
        reference_number=reference_number,
        booking_date=datetime.utcnow().date()
    )
    
    trip.available_seats -= 1
    
    db.session.add(ticket_data)
    db.session.commit()
    
    return jsonify({'success': True, 'ticket': {
        'id': ticket_data.id,
        'trip_id': ticket_data.trip_id,
        'passenger_name': ticket_data.passenger_name,
        'passenger_id': ticket_data.passenger_id,
        'passenger_phone': ticket_data.passenger_phone,
        'reference_number': ticket_data.reference_number,
        'booking_date': str(ticket_data.booking_date)
    }, 'message': 'Ticket booked successfully'})

@app.route('/api/cancel_ticket', methods=['POST'])
def cancel_ticket():
    if session.get('user_role') != 'passenger':
        return jsonify({'success': False, 'message': 'Unauthorized'})
    
    reference_number = request.form.get('reference_number')
    ticket = Ticket.query.filter_by(reference_number=reference_number).first()
    
    if not ticket:
        return jsonify({'success': False, 'message': 'Ticket not found'})
    
    # Find the trip and increase available seats
    trip = Trip.query.get(ticket.trip_id)
    if trip:
        trip.available_seats += 1
    
    # Remove ticket
    db.session.delete(ticket)
    db.session.commit()
    
    return jsonify({'success': True, 'message': 'Ticket cancelled successfully'})

# Initialize database on startup
init_database()

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)