// Main JavaScript file for PTMS

// Global variables
let currentModal = null;

// Garage Manager Functions
function editBus(bus) {
    document.getElementById('editBusId').value = bus.id;
    document.getElementById('editPlateNumber').value = bus.plate_number;
    document.getElementById('editBusType').value = bus.type;
    document.getElementById('editBusModel').value = bus.model;
    document.getElementById('editCapacity').value = bus.capacity;
    document.getElementById('editStatus').value = bus.status;
    
    const modal = new bootstrap.Modal(document.getElementById('editBusModal'));
    modal.show();
}

function respondToComplaint(complaintId) {
    document.getElementById('complaintId').value = complaintId;
    const modal = new bootstrap.Modal(document.getElementById('complaintResponseModal'));
    modal.show();
}

// Driver Functions
function updateTripStatus(tripId, currentStatus) {
    document.getElementById('statusTripId').value = tripId;
    document.getElementById('newStatus').value = currentStatus;
    
    const modal = new bootstrap.Modal(document.getElementById('tripStatusModal'));
    modal.show();
}

// Passenger Functions
function filterTrips() {
    const searchTerm = document.getElementById('searchTrips').value.toLowerCase();
    const dateFilter = document.getElementById('filterDate').value;
    const rows = document.querySelectorAll('#tripsTable tbody tr');
    
    rows.forEach(row => {
        const routeText = row.cells[1].textContent.toLowerCase();
        const dateText = row.cells[2].textContent;
        
        const matchesSearch = !searchTerm || routeText.includes(searchTerm);
        const matchesDate = !dateFilter || dateText === dateFilter;
        
        row.style.display = (matchesSearch && matchesDate) ? '' : 'none';
    });
}

// Form submission handlers
document.addEventListener('DOMContentLoaded', function() {
    // Add Bus Form
    const addBusForm = document.getElementById('addBusForm');
    if (addBusForm) {
        addBusForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch('/api/add_bus', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Refresh the page to show updated bus data
                    location.reload();
                } else {
                    showAlert('خطأ في إضافة الحافلة: ' + data.message, 'danger');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showAlert('حدث خطأ أثناء إضافة الحافلة.', 'danger');
            });
        });
    }

    // Add Driver Form
    const addDriverForm = document.getElementById('addDriverForm');
    if (addDriverForm) {
        addDriverForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch('/api/add_driver', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Add new row to drivers table
                    const tbody = document.getElementById('driversTable');
                    const newRow = tbody.insertRow();
                    newRow.innerHTML = `
                        <td>${data.driver.id}</td>
                        <td>${data.driver.name}</td>
                        <td>${data.driver.license_no}</td>
                        <td>${data.driver.phone}</td>
                        <td>${data.driver.email}</td>
                    `;
                    
                    // Close modal and reset form
                    bootstrap.Modal.getInstance(document.getElementById('addDriverModal')).hide();
                    this.reset();
                    
                    showAlert(`تم إضافة السائق بنجاح! اسم المستخدم: ${data.user.username}`, 'success');
                } else {
                    showAlert('خطأ في إضافة السائق: ' + data.message, 'danger');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showAlert('An error occurred while adding the driver.', 'danger');
            });
        });
    }

    // Edit Bus Form
    const editBusForm = document.getElementById('editBusForm');
    if (editBusForm) {
        editBusForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch('/api/update_bus', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Refresh the page to show updated bus data
                    location.reload();
                } else {
                    showAlert('Error updating bus: ' + data.message, 'danger');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showAlert('An error occurred while updating the bus.', 'danger');
            });
        });
    }

    // Add Route Form
    const addRouteForm = document.getElementById('addRouteForm');
    if (addRouteForm) {
        addRouteForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch('/api/add_route', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Add new row to routes table
                    const tbody = document.getElementById('routesTable');
                    const newRow = tbody.insertRow();
                    newRow.innerHTML = `
                        <td>${data.route.id}</td>
                        <td>${data.route.start_point}</td>
                        <td>${data.route.end_point}</td>
                        <td>${data.route.description}</td>
                    `;
                    
                    // Close modal and reset form
                    bootstrap.Modal.getInstance(document.getElementById('addRouteModal')).hide();
                    this.reset();
                    
                    showAlert('Route added successfully!', 'success');
                } else {
                    showAlert('Error adding route: ' + data.message, 'danger');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showAlert('An error occurred while adding the route.', 'danger');
            });
        });
    }

    // Add Trip Form
    const addTripForm = document.getElementById('addTripForm');
    if (addTripForm) {
        addTripForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch('/api/add_trip', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Close modal and reset form
                    bootstrap.Modal.getInstance(document.getElementById('addTripModal')).hide();
                    this.reset();
                    
                    showAlert('Trip scheduled successfully!', 'success');
                    // Refresh page to show new trip
                    setTimeout(() => location.reload(), 1000);
                } else {
                    showAlert('Error scheduling trip: ' + data.message, 'danger');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showAlert('An error occurred while scheduling the trip.', 'danger');
            });
        });
    }

    // Complaint Response Form
    const complaintResponseForm = document.getElementById('complaintResponseForm');
    if (complaintResponseForm) {
        complaintResponseForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch('/api/respond_complaint', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    bootstrap.Modal.getInstance(document.getElementById('complaintResponseModal')).hide();
                    this.reset();
                    showAlert('Response sent successfully!', 'success');
                    setTimeout(() => location.reload(), 1000);
                } else {
                    showAlert('Error sending response: ' + data.message, 'danger');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showAlert('An error occurred while sending the response.', 'danger');
            });
        });
    }

    // Emergency Form (Driver)
    const emergencyForm = document.getElementById('emergencyForm');
    if (emergencyForm) {
        emergencyForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch('/api/submit_emergency', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    this.reset();
                    showAlert('Emergency notification sent successfully!', 'success');
                } else {
                    showAlert('Error sending emergency notification: ' + data.message, 'danger');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showAlert('An error occurred while sending the emergency notification.', 'danger');
            });
        });
    }

    // Trip Status Form (Driver)
    const tripStatusForm = document.getElementById('tripStatusForm');
    if (tripStatusForm) {
        tripStatusForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch('/api/update_trip_status', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    bootstrap.Modal.getInstance(document.getElementById('tripStatusModal')).hide();
                    showAlert('Trip status updated successfully!', 'success');
                    setTimeout(() => location.reload(), 1000);
                } else {
                    showAlert('Error updating trip status: ' + data.message, 'danger');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showAlert('An error occurred while updating the trip status.', 'danger');
            });
        });
    }

    // Driver Complaint Form
    const driverComplaintForm = document.getElementById('driverComplaintForm');
    if (driverComplaintForm) {
        driverComplaintForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch('/api/file_complaint', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    this.reset();
                    showAlert('Complaint submitted successfully!', 'success');
                } else {
                    showAlert('Error submitting complaint: ' + data.message, 'danger');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showAlert('An error occurred while submitting the complaint.', 'danger');
            });
        });
    }

    // Book Ticket Form (Passenger)
    const bookTicketForm = document.getElementById('bookTicketForm');
    if (bookTicketForm) {
        bookTicketForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch('/api/book_ticket', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    this.reset();
                    
                    // Show booking confirmation
                    const ticketDetails = document.getElementById('ticketDetails');
                    ticketDetails.innerHTML = `
                        <h6>Ticket Details:</h6>
                        <p><strong>Reference Number:</strong> ${data.ticket.reference_number}</p>
                        <p><strong>Passenger:</strong> ${data.ticket.passenger_name}</p>
                        <p><strong>ID:</strong> ${data.ticket.passenger_id}</p>
                        <p><strong>Phone:</strong> ${data.ticket.passenger_phone}</p>
                        <p><strong>Booking Date:</strong> ${data.ticket.booking_date}</p>
                        <hr>
                        <p class="text-success"><strong>Please save your reference number for future use.</strong></p>
                    `;
                    
                    const modal = new bootstrap.Modal(document.getElementById('bookingConfirmationModal'));
                    modal.show();
                } else {
                    showAlert('Error booking ticket: ' + data.message, 'danger');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showAlert('An error occurred while booking the ticket.', 'danger');
            });
        });
    }

    // Cancel Ticket Form (Passenger)
    const cancelTicketForm = document.getElementById('cancelTicketForm');
    if (cancelTicketForm) {
        cancelTicketForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch('/api/cancel_ticket', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    this.reset();
                    showAlert('Ticket cancelled successfully!', 'success');
                } else {
                    showAlert('Error cancelling ticket: ' + data.message, 'danger');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showAlert('An error occurred while cancelling the ticket.', 'danger');
            });
        });
    }

    // Passenger Complaint Form
    const passengerComplaintForm = document.getElementById('passengerComplaintForm');
    if (passengerComplaintForm) {
        passengerComplaintForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch('/api/file_complaint', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    this.reset();
                    showAlert('Complaint submitted successfully!', 'success');
                } else {
                    showAlert('Error submitting complaint: ' + data.message, 'danger');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showAlert('An error occurred while submitting the complaint.', 'danger');
            });
        });
    }

    // Search and filter functionality for passenger trips
    const searchTrips = document.getElementById('searchTrips');
    const filterDate = document.getElementById('filterDate');
    
    if (searchTrips) {
        searchTrips.addEventListener('input', filterTrips);
    }
    
    if (filterDate) {
        filterDate.addEventListener('change', filterTrips);
    }
});

// Utility function to show alerts
function showAlert(message, type) {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
    alertDiv.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    const container = document.querySelector('.container');
    container.insertBefore(alertDiv, container.firstChild);
    
    // Auto-dismiss after 5 seconds
    setTimeout(() => {
        if (alertDiv.parentNode) {
            alertDiv.remove();
        }
    }, 5000);
}
